
package com.ey8;

import java.util.Random;

public class Advisor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] advices = {
				"Be kind to yourself",
				"Work hard and never give up",
				"Stay focused"
		
		};
		Random random = new Random();
		int randomIndex=random.nextInt(advices.length);
		
		System.out.println("Here is your advice:" +advices[randomIndex]);
	}

}
