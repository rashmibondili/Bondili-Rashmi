package com.ey8;

public class Manager extends Thread {
	
		private String name;
		private ConferenceRoom conferenceRoom;
		
	public Manager(String name, ConferenceRoom conferenceRoom) {
		this.name=name;
		this.conferenceRoom=conferenceRoom;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	public void run() {
		while (true) {
			if (conferenceRoom.checkAvailability()) {
				if (conferenceRoom.bookRoom()) {
					System.out.println(name + " has booked the conference room");
					try {
						Thread.sleep(3000);
					} catch(InterruptedException e){
						e.printStackTrace();
					}
					System.out.println(name + "has finished the meeting");
					conferenceRoom.releaseRoom();
					break;
				} else {
					System.out.println(name + "is waiting for the room to become available");
					try {
						Thread.sleep(1000);
					} catch(InterruptedException e){
						e.printStackTrace();
					}
						
					}
				}
				
			}
		}
	}
	


	