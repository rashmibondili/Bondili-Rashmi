package com.ey8;

public class ConferenceRoom {
	private boolean available=true;
	
	public synchronized boolean checkAvailability() {
		return available;
	}
	public synchronized boolean bookRoom() {
		if(available) {
			available=false;
			return true;
			
		}else {
			return false;
		}
	}
	public synchronized void releaseRoom() {
		available = true;
	}
}
	
	
		
	

	


