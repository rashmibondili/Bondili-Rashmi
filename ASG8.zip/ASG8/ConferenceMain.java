package com.ey8;


public class ConferenceMain{
		
		public static void main(String[] args) {
			ConferenceRoom conferenceRoom=new ConferenceRoom();
			
			Manager manager1=new Manager("Manager1", conferenceRoom);
			Manager manager2=new Manager("Manager2", conferenceRoom);
			
			manager1.start();
			manager2.start();
			
			try {
				manager1.join();
				manager2.join();
			} catch(InterruptedException e) {
				e.printStackTrace();
				
			}
			System.out.println("Both meetings are completed");
		}
	}





