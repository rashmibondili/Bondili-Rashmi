package com.ey8;



import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public  class FileCopy1 implements Runnable  {

	
	@Override
	public void run() {
		copyFile("image.1.bmp", "temp.bmp");
	
		
	}
	private void copyFile(String source, String destination) {
		try (FileInputStream in = new FileInputStream(source);
				OutputStream out = new FileOutputStream(destination)) {
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = in.read(buffer)) != -1) {
				out.write(buffer, 0, bytesRead);
			}
			System.out.println("File copied from " + source + " to " + destination);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		new Thread(new FileCopy1()).start();
		
	}

}



