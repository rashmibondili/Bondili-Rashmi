package com.ey8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class FileCopy2 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		copyFile("image.2.bmp", "temp.bmp");
		copyFile("image.2.bmp", "image2.bmp");
		
	}
	private void copyFile(String source, String destination) {
		try (FileInputStream in = new FileInputStream(source);
				OutputStream out = new FileOutputStream(destination)) {
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = in.read(buffer)) != -1) {
				out.write(buffer, 0, bytesRead);
			}
			System.out.println("File copied from " + source + " to " + destination);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void main (String[] args){
		new Thread(new FileCopy2()).start();
		
	}
}