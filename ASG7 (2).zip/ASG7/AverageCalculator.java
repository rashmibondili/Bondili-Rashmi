package com.ey.day07;

import java.util.Scanner;

public class AverageCalculator {
	public double calAverage(int n) {
		if (n<=0) {
			throw new IllegalArgumentException("The input must be a positive integer");
		}
		int sum = n * (n+1)/2;
		return (double) sum / n;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AverageCalculator calculator = new AverageCalculator();
		Scanner scanner = new Scanner(System.in);
		try {
			System.out.print("Enter a positive integer n: ");
			int n = scanner.nextInt();
			
			double average = calculator.calAverage(n);
			System.out.print("The average of first" + n + "natural numbers is: " + average);
		} catch (IllegalArgumentException e) {
			System.out.print("Error: " + e.getMessage());
		}

	}

}
