package com.ey.day07;

public class BankAccount {
	private int accno;
	private String custname;
	private String acctype;
	private float balance;
	
	private static final float MIN_BAL = 1000.0f;
	private static final float MAX_BAL = 5000.0f;
	

	public BankAccount(int accno, String custname, String acctype, float balance) {
		super();
		this.accno = accno;
		this.custname = custname;
		this.acctype = acctype;
		this.balance = balance;
	}
	public void deopsit(float amount) {
		if (amount <= 0) {
			throw new IllegalArgumentException("Amount should be greater than zero");
			
		}balance += amount;
		System.out.println("Deposited: " + amount);
	}
	public void withdraw(float amount) {
		if (amount <= 0) {
			throw new IllegalArgumentException("Amount should be greater than zero");
			
		}
		if (balance - amount < MIN_BAL) {
			throw new IllegalArgumentException("Insufficient Funds");
			
		}
		if (balance - amount > MAX_BAL) {
			throw new IllegalArgumentException("MAximum Balance Exceeded");
			
		}
		balance -= amount;
		System.out.println("withdrew: " + amount);
	}
	public float getBalance() {
		return balance;
	}
	public static void main(String[] args) {
		BankAccount account = new BankAccount(12345, "Rashmi", "savings", 3000.0f);
		
		System.out.println("Initial Balance: " + account.getBalance());
		
		account.deopsit(500.0f);
		System.out.println("Balance after deposit: " + account.getBalance());
		
		account.withdraw(2000.0f);
		System.out.println("Final Balance: " + account.getBalance());
		
		account.withdraw(4000.0f);
		System.out.println("Final Balance: ");

		

	}

}
