package com.ey.day07;

import java.util.HashMap;

import javax.security.auth.login.AccountNotFoundException;

public class AccountChecker {
	private String accountNumber;
	private double balance;
	private static HashMap<String, AccountChecker> accounts = new HashMap<>();
	
	public AccountChecker(String accountNumber, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
	}
	
   private static boolean isValidAcc(int accno) throws AccountNotFoundException {
		if (accounts.containsKey(accno)) {
			return true;
		} else {
			throw new AccountNotFoundException("Acc not found");
		}
	}
   public void getAccno() {
	   return accno;
   }
   public double getBalance() {
	   return balance;
	   
   }
   public void deposit(double amount) {
	   balance += amount;
   }
   public void withdraw(double amount) {
	   if (balance >= amount) {
		   balance -= amount;
	   }else {
		   System.out.println("Insufficient Funds");
	   }
   }
}
class AccountNotFoundException extends Exception {
	public AccountNotFoundException(String message) {
		super(message);
	}
}
public class BankAccount {
	public static void main(String[] args) {
		AccountChecker account1=new AccountChecker("123456789", 1000.0);
		AccountChecker account2=new AccountChecker("987654321", 2000.0);
		try {
			boolean isValid = BankAccount.isValidAccount("123456789");
			System.out.println("account exists: " + isValid);
			
			isValid = BankAccount.isValidAccount("999999999");
			System.out.println("Account exists: " + isValid);
		} catch (AccountNotException e) {
			System.out.println(e.getMessage());
		}
	}
}
