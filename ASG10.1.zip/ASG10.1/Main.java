package com.ey10;

import java.util.Arrays;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Author> authors  = Arrays.asList(
				new Author("Adam smith", Arrays.asList("Book1", "Book2"), 50, "NYC", "female", "1234567", "A12"),
			
				new Author("Alice john", Arrays.asList("Book3"), 40, "UK", "male", "12567", "B987"),
				
			
				new Author("Pryanka Jain", Arrays.asList("Book4", "Book5"), 30, "INDIA", "female", "12345", "S67")
				);
		
				AuthorService authorService = new AuthorServiceImp1();
				
				System.out.println("Unique Surnames: " +
				authorService.getUniqueSurnames(authors));
				
				System.out.println("Authors by city: " +
						authorService.getAuthorsByCity(authors));
				
				System.out.println("Average age of female Authors: " +
						authorService.getFemaleAverageAge(authors));
				
				System.out.println("Mobile by aadhar(A12: " +
						authorService.getMobileByAadhar(authors, "A12"));

	}

}
