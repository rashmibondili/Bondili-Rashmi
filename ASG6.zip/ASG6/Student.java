package com.ey5;

import java.util.Objects;

public class Student {
	
		
		private String firstname;;
		private String lastname;
		private String age;
		private Address address;
		
		

	public Student(String firstname, String lastname, String age, Address address) {
			super();
			this.firstname = firstname;
			this.lastname = lastname;
			this.age = age;
			this.address = address;
		}
	
		// TODO Auto-generated constructor stub
	
	public Student(String string, String string2, int i) {
		// TODO Auto-generated constructor stub
	}

	public String getFirstName() {
		return firstname;
	
	}
	public void setFirstName(String firstName) {
		this.firstname=firstName;
	}
	public String getLastname() {
		return lastname;
	
	}
	public void setLastName(String lastName) {
		this.lastname=lastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age=age;
		
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address=address;
	}
	
	
public boolean equals(Object o) {
	if (this == o) return true;
	if (o == null || getClass() != o.getClass()) return false;
	Student student = (Student) o;
	return age == student.age &&
			Objects.equals(lastname, student.lastname) && Objects.equals(address,  student.address);
}
public int hashCode() {
		return 
				Objects.hash(firstname, lastname, age, address);
	}
	public String toString() {
		return 
				firstname + " " + lastname + ", Age: " + age + ", Address: " +address;
	}
			
			
			


	
	
	}


