package com.ey5;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Movie implements Comparable<Movie> {
	private String name;
	private String language;
	private String releaseDate;
	private String director;
	private String producer;
	private int duration;
	
	

	public Movie(String name, String language, String releaseDate, String director, String producer, int duration) {
		super();
		this.name = name;
		this.language = language;
		this.releaseDate = releaseDate;
		this.director = director;
		this.producer = producer;
		this.duration = duration;
	}
	public String getname() {
		return name;
	}
	public String getlanguage() {
		return language;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public String getDirector() {
		return director;
	}
	public String getProducer() {
		return producer;
	}
	public int getDuration() {
		return duration;
	}
	public int compareTo(Movie other) {
		return this.language.compareTo(other.language);
		
	}
	public String toString() {
		return "Movie{" + "name=' "+ name + '\"'+
				", language=' " + language + '\"'+
				", releaseDate=' " + releaseDate + '\"'+
				", director=' " + director + '\"'+
				", producer=' " + producer + '\"'+
				", duration=' " + duration + '\"'+
				'}';
	

	}
	public static void sortByLanguage(List<Movie>movieList) {
		Collections.sort(movieList);
	}
	public static void sortByDirector(List<Movie>movieList) {
		movieList.sort(new Comparator<Movie>() {
			public int compare(Movie m1, Movie m2) {
				return m1.getDirector().compareTo(m2.getDirector());
			}
		});
	}
    public static void main(String[] args) {
		// TODO Auto-generated method stub
    List<Movie> movieList = new ArrayList<>();
    movieList.add(new Movie("Murari", "Telugu", "2006-08-24", "Mahesh", "Sitara",123));
    movieList.add(new Movie("Parasite", "Korean", "2019-08-05", "Boong", "Kwak",132));
    movieList.add(new Movie("Godzilla", "English", "2010-03-17", "Francis", "albert",543));
    
    System.out.println("Orginal List:");
    for(Movie movie : movieList) {
    	System.out.println(movie);
    	
    }
    Movie.sortByLanguage(movieList);
    System.out.println("\nSorted by language:");
    for(Movie movie : movieList) {
    	System.out.println(movie);
    }
    	
    Movie.sortByDirector(movieList);
    System.out.println("\nSorted by language:");
    for(Movie movie : movieList) {
    	System.out.println(movie);
    
   

	}

   }
 }

