package com.ey5;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Employee {
	private int empid;
	private String firstname;
	private String lastname;
	public List<Object> employees;
	
	

	public Employee(int empid, String firstname, String lastname) {
		this.empid = empid;
		this.firstname = firstname;
		this.lastname = lastname;
	}
	public int getEmpid() {
		return empid;
	}
	public String getFirstname() {
		return firstname;
	}
	public String getlastname() {
		return lastname;
	}
	public String toString() {
		return "Employee{" + "empid=' "+ empid + '\"'+
				", firstname=' " + firstname + '\"'+
				", lastname=' " + lastname + '\"'+
				'}';
	}
class EmployeeCollection {
	private List<Employee> employee;
	
	public EmployeeCollection() {
		ArrayList<Object> employees = new ArrayList<>();
	}
	public void addEmployee(int empid, String firstname, String lastname) {
		for (employee emp : employees) {
			if(emp.getEmpid()==empid) {
				System.out.println("Employee with empid " + empid + "already exists. Skipping.");
				return;
			}
		}
		String lastnameint;
		Employee newEmployee = new Employee(empid, lastname, lastnameint empid, String firstname, String lastname);
		employees.add(newEmployee);
	}
	public void sortEmployees(String key) {
		if("empid".equals(key)) {
			List<Object> employees;
			Collections.sort(employees, Comparator.comparing.comparingInt(Employee::getEmpid));
			
		}
	}elseif("firstname".equals(key)) {
	
		Collections.sort(employees, Comparator.comparing.comparingInt(Employee::getFirstname));
		
	}
	public void printEmployees() {
		// TODO Auto-generated method stub
		
	}
	
	
}
public void printEmployees() {
	for (Object emp : employees) {
		System.out.println(emp);
	
	}
}
public class Main {
	public void main(String[] args) {
		EmployeeCollection collection = new EmployeeCollection();
		
		collection.addEmployee(1,  "Rashmi", "Bondili");
		collection.addEmployee(1,  "Sudha", "Rani");
		collection.addEmployee(1,  "Bhanu", "Priya");
		collection.addEmployee(1,  "Joe", "Biden");
		
		System.out.println("Employee sorted by empid:");
		collection.sortEmployees("empid");
	    collection.printEmployees();
	    
	    System.out.println("\nEmployee sorted by firstname:");
		collection.sortEmployees("firstname");
	    collection.printEmployees();;
	
}





	
	}


