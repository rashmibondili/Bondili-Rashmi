package com.ey5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class CityStateMap extends HashMap<String, String> {
	


	public CityStateMap() {
		super();
	}
	public void addCityState(String city, String state) {
		this.put(city,  state);
	}
	public Set<String> getAllCities() {
		return this.keySet();
	}
	public Collection<String> getAllStates() {
		return this.values();
		
	}
	public void loadFromFile(String filename) throws IOException {
		try (BufferedReader br=new BufferedReader(new FileReader(filename))) {
			String line;
			while((line = br.readLine()) != null) {
				String[] parts=line.split(" , ");
				if(parts.length == 2) {
					addCityState(parts[0].trim(),parts[1].trim());
				}
			}
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CityStateMap cityStateMap=new CityStateMap();
		
		try {
			cityStateMap.loadFromFile("city_state.txt");
			System.out.println("Cities: " + cityStateMap.getAllCities());
			System.out.println("States: " + cityStateMap.getAllStates());
		} catch (IOException e) {
			System.out.println("Error.");
			e.printStackTrace();
		}

	}

}
