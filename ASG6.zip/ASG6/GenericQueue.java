package com.psl.day06.util;
import java.util.LinkedList;


public class GenericQueue<T> {
	private LinkedList<T> queue;
	
	public GenericQueue() {
		queue = new LinkedList<>();
		
	}
	public void enqueue(T item) {
		queue.addLast(item);
	}
	public T dequeue() {
		if(isEmpty1()) {
			throw new IllegalStateException("Queue is empty");
			
		}return queue.removeFirst();
	}
	public boolean isEmpty1() {
		return queue.isEmpty();
	}
	public T peek() {
		if (isEmpty1()) {
throw new IllegalStateException("Queue is empty");
			
		}return queue.removeFirst();
		}
	public void printQueue() {
		for (T item : queue) {
			System.out.println(item);
		}
	}
	public static void main(String[] args) {
		GenericQueue<Integer> intQueue = new GenericQueue<>();
		intQueue.enqueue(1);
		intQueue.enqueue(2);
		intQueue.enqueue(3);
		System.out.println("Queue of Integers:");
		intQueue.printQueue();
		System.out.println("Dequeued: " + intQueue.dequeue());
		intQueue.printQueue();
		
		GenericQueue<Double> doubleQueue = new GenericQueue<>();
		doubleQueue.enqueue(1.1);
		doubleQueue.enqueue(2.2);
		doubleQueue.enqueue(3.3);
		System.out.println("\nQueue of Doubles:");
		doubleQueue.printQueue();
		System.out.println("Dequeued: " + doubleQueue.dequeue());
		doubleQueue.printQueue();
		
		GenericQueue<String> stringQueue = new GenericQueue<>();
		stringQueue.enqueue("one");
		stringQueue.enqueue("two");
		stringQueue.enqueue("three");
		System.out.println("\nQueue of Strings:");
		stringQueue.printQueue();
		System.out.println("Dequeued: " + stringQueue.dequeue());
		stringQueue.printQueue();

	}
	
}
