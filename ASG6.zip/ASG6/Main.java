package com.ey5;

import java.util.HashSet;

public class Main {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address address1=new Address("123 Raparhy Nagar", "1l", "12345");
		Address address2=new Address("456 Rotary Nagar", "1l", "12346");
		
		Student student1=new Student("Rashmi", "Sudha", 23);
		Student student2=new Student("Bhanu", "Shyam", 20);
		Student student3=new Student("Rashmi", "Sudha", 23);
		
		HashSet<Student> students=new HashSet<>();
		students.add(student1);
		students.add(student2);
		students.add(student3);
		for(Student student: students) {
			System.out.println(student);
		}
	}

}
