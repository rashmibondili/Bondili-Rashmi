package com.ey9;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class FileCopyUtility {
	

	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java FileCopyUtility <source-file> <destination-file>");
			return;
		}
		String sourceFile = args[0];
		String destinationFile = args[1];
		
		copyFile(sourceFile, destinationFile);

	}
	public static void copyFile(String sourceFile, String destinationFile) {
		Scanner scanner = new Scanner(System.in);
		Path srcPath = Paths.get(sourceFile);
		Path destPath = Paths.get(destinationFile);
		try {
			if (!Files.exists(srcPath)) {
				throw new FileNotFoundException("Source file '" + sourceFile + "' not found.");
				
			} if (Files.exists(destPath)) {
				System.out.println("The file '" + destinationFile + "' already exists. Do you want to obverwrite it?");
				String response = scanner.nextLine();
				if (! response.equalsIgnoreCase("yes")) {
					System.out.println("Operation aborted by user");
					return;
				}
			}
			Files.copy(srcPath, destPath, StandardCopyOption.REPLACE_EXISTING);
			System.out.println("File '" + sourceFile + "' successfully copied to '"+ destinationFile + "'.");
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			
		} catch (IOException e) {
			System.out.println("An error occured: " + e.getMessage());
		} finally {
			scanner.close();
		}
	}

}
