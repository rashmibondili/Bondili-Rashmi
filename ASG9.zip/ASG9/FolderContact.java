package com.ey9;

import java.io.File;

public class FolderContact {
	

	public static void displayFolder(String folderPath) {
		File folder = new File(folderPath);
		if (folder.isDirectory()) {
			System.out.println(folder);
			File[] subfolder = folder.listFiles(File::isDirectory);
			if(subfolder != null) {
				for(File f: subfolder) {
					displayFolder(f.getAbsolutePath());
				}
			}
		}
		

	}
	public static void main(String[] args) {
		String currentDirectory = System.getProperty("user.dir");
		displayFolder(currentDirectory);
	}

}
