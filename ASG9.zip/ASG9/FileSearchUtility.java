package com.ey9;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

import java.util.Scanner;

public class FileSearchUtility {
	public static List<Path> findFile(Path searchPath, String fileName) {
		List<Path> result = new ArrayList<>();
		
		try {
			Files.walkFileTree(searchPath, new SimpleFileVisitor<Path>() {
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
					if (file.getFileName().toString().equals(fileName)) {
						result.add(file);
					} return FileVisitResult.CONTINUE;
				}
				
			});
		} catch (IOException e) {
			System.out.println("An error occured: " + e.getMessage());
			
		}return result;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the directory path to search");
	
		String searchPathString = scanner.nextLine();
		Path searchPath = Paths.get(searchPathString);
		
		System.out.println("Enter the filename to search: ");
		String fileName = scanner.nextLine();
		List<Path> foundFiles = findFile(searchPath, fileName);
		
		if (!foundFiles.isEmpty()) {
			System.out.println("Found " + fileName + " at the following locations:");
			for (Path filePath : foundFiles) {
				System.out.println(filePath.toString());
			}
		} else {
			System.out.println("No file named " + fileName + " found in the specified path");
		}
		scanner.close();

	}

}
