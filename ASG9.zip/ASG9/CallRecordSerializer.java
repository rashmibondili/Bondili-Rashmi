package com.ey9;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

import com.sun.tools.javac.util.List;

public class CallRecordSerializer {
	

	public static void main(String[] args) {
		Scanner scanner =  new Scanner(System.in);
		ArrayList callRecords = new ArrayList();
		
		while (true) {
			System.out.print("Enter fromNumber: ");
			int fromNumber = scanner.nextInt();
			System.out.print("Enter toNumber: ");
			int toNumber = scanner.nextInt();
			System.out.print("Enter duration (in minutes): ");
			float duration = scanner.nextFloat();
			
			CallDetailRecord record = new CallDetailRecord(fromNumber, toNumber, duration);
			callRecords.add(record);
			System.out.print("Do you want to add another record?");
			String response = scanner.next();
			if (!response.equalsIgnoreCase("yes")) {
				break;
			}
					
			
					
		}
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("ChargeRecord.ser"))){
			out.writeObject(callRecords);
			System.out.println("Call records have been serialized to 'ChargeRecord.ser'.");
			
			
		} catch (IOException e) {
			System.out.println("An error occured during serialization: " + e.getMessage());
			
			
		}
		scanner.close();

	}

}
