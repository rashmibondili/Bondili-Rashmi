package com.ey9;

import java.io.Serializable;

public class CallDetailRecord implements Serializable {
	private static final long serialVersionUID = 1L;
	private int fromNumber;
	private int toNumber;
	private float duration;
	private float charge;
	
	public CallDetailRecord(int fromNumber, int toNumber, float duration) {
		super();
		this.fromNumber = fromNumber;
		this.toNumber = toNumber;
		this.duration = duration;
		this.charge = duration * 1.0f;
	}
	public int getFromNumber() {
		return fromNumber;
	}
	public int getToNumber() {
		return toNumber;
	}
	public float getDuration() {
		return duration;
	}
	public float getCharge() {
		return charge;
	}
}
