import React from 'react';

const Contact = () => {
    return (
        <div>
            <h1>
                Constant Page
            </h1>
            <p>This is the conatct page.</p>
        </div>
    );
};
export default Contact;