import React from 'react';

const AboutUs = () => {
    return (
        <div>
            <h1>
                About Us Page
            </h1>
            <p>This is the about us page.</p>
        </div>
    );
};
export default AboutUs;