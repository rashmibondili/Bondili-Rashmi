import React, { useState } from 'react';
const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});

    const handleSubmit = (e) => {
        e.preventDefault();
        let errors = {};

        if (!email.includes('@')) {
            errors.email = 'Email is invalid';

        }
        if (password.length<6) {
            errors.password = 'Password should be atleast 6 characters';

        }
        setErrors(errors);

        if (Object.keys(errors).length === 0) {
            console.log('Form submitted');

        }

    };
    return (
        <div>
            <h1>Login Page</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>
                        Email:
                    </label>
                    <input
                       type="email"
                       value={email}
                       onChange={(e) => setEmail(e.target.value)}
                    />
                    {errors.email && <span>{errors.email}</span>}
                </div>
                <div>
                <label>
                        Password:
                    </label>
                    <input
                       type="password"
                       value={password}
                       onChange={(e) => setPassword(e.target.value)}
                    />
                    {errors.password && <span>{errors.password}</span>}
                </div>
                <button
                type="submit">Login</button>

                
            </form>
        </div>
    );
};
export default Login;